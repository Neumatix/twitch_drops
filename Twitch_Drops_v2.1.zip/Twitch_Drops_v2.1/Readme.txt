Twitch_Drops_v2.1 by Neumatix
-Auto collects drops from twitch on all games connected to twitch account.
#Instructions

1- Install Python 3.8 *MAKE SURE YOU CHECK "Add to environmental variable" WHEN INSTALLING
	'https://www.python.org/ftp/python/3.8.7/python-3.8.7.exe' - Intel CPU
	'https://www.python.org/ftp/python/3.8.7/python-3.8.7-amd64.exe' - AMD CPU

2- Run Install Bat File *Right Click Select "Run As Administrator"

3- Run Start_Bot Bat File *Right Click Select "Run As Administrator"

*NOTES
-Fair Warning, Chrome will close when you first launch "Start_Bot", after that just use chrome as normal.
-You need to be logged into your twitch account before starting bot, using remember me or stay logged in setting.
-You still need to manually connect games to twitch account first (on twitch same requirement as doing it manually)
-Requires Chrome Version 87 (latest), with chrome installed on C:/ aka "C Drive"
	if you get a compatability error for chrome driver it is likely due to chrome auto updating
	download the matching version from 'https://chromedriver.chromium.org/downloads' and replace the "chromedriver.exe" file in "Twitch_Drops" folder.
-if Install Bat file throws an error, double check "Add to environmental variable" box is ticked by relaunching python installer and selecting "Modify"